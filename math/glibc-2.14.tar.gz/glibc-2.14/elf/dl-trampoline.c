#error "Architecture specific PLT trampolines must be defined."
